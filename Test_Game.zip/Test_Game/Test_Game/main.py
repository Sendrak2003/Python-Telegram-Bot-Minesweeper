﻿from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler
from config import TOKEN
from handlers import start, new_game, set_game_parameters, handle_button_click, reveal_cell

def main() -> None:
    application = ApplicationBuilder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("newgame", new_game))
    application.add_handler(CommandHandler("setgame", set_game_parameters))
    application.add_handler(CommandHandler("reveal", reveal_cell))
    application.add_handler(CallbackQueryHandler(handle_button_click))
    application.run_polling()

if __name__ == '__main__':
    main()
