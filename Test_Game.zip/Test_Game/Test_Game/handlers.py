﻿from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from game import Minesweeper

# Словарь для хранения состояния игр пользователей
games = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обрабатывает команду /start. Отправляет приветственное сообщение.
    """
    await update.message.reply_text('Привет! Давай сыграем в Сапёр! Напиши /newgame для начала.')

async def new_game(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обрабатывает команду /newgame. Создает новую игру с параметрами по умолчанию.
    """
    game = Minesweeper(5, 5, 5)  # По умолчанию 5x5 и 5 мин
    game.place_mines()
    game.calculate_numbers()
    games[update.message.chat.id] = game
    await show_keyboard(update)

async def set_game_parameters(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обрабатывает команду /setgame. Устанавливает параметры для новой игры.
    
    Ожидает три аргумента: ширина, высота и количество мин.
    """
    try:
        width = int(context.args[0])
        height = int(context.args[1])
        mines = int(context.args[2])
        if width <= 0 or height <= 0 or mines <= 0 or mines >= width * height:
            raise ValueError
        game = Minesweeper(width, height, mines)
        game.place_mines()
        game.calculate_numbers()
        games[update.message.chat.id] = game
        await show_keyboard(update)
    except (ValueError, IndexError):
        await update.message.reply_text('Неправильные параметры. Используйте: /setgame width height mines')

async def show_keyboard(update: Update):
    """
    Показывает клавиатуру с вариантами действий игрока.
    """
    keyboard = [
        [InlineKeyboardButton("⬆️", callback_data='move_up'),
         InlineKeyboardButton("⬇️", callback_data='move_down'),
         InlineKeyboardButton("⬅️", callback_data='move_left'),
         InlineKeyboardButton("➡️", callback_data='move_right')],
        [InlineKeyboardButton("🔍", callback_data='reveal')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Выберите направление или откройте клетку:\n' + games[update.message.chat.id].display_board(), reply_markup=reply_markup)

async def handle_button_click(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обрабатывает нажатия на кнопки управления (движение и раскрытие клеток).
    """
    query = update.callback_query
    await query.answer()  # Подтверждаем нажатие кнопки
    chat_id = query.message.chat.id
    
    if chat_id not in games:
        await query.message.reply_text('Сначала начни новую игру с помощью /newgame или /setgame.')
        return
    
    game = games[chat_id]
    command = query.data

    # Логика движения
    if command == 'move_up' and game.player_y > 0:  # Проверка верхней границы
        game.player_y -= 1
    elif command == 'move_down' and game.player_y < game.height - 1:  # Проверка нижней границы
        game.player_y += 1
    elif command == 'move_left' and game.player_x > 0:  # Проверка левой границы
        game.player_x -= 1
    elif command == 'move_right' and game.player_x < game.width - 1:  # Проверка правой границы
        game.player_x += 1
    elif command == 'reveal':
        # Проверка на попадание на мину
        if (game.player_x, game.player_y) in game.mines_set:
            new_text = 'Вы попали на мину! Игра окончена.\n' + game.display_board()
            del games[chat_id]
            await query.message.reply_text(new_text)  # Отправляем новое сообщение с результатом
            return
        
        if game.reveal(game.player_x, game.player_y):
            new_text = game.display_board()
        else:
            new_text = 'Эта клетка уже открыта.\n' + game.display_board()
        
        # Обновляем сообщение только если текст изменился
        try:
            if query.message.text != new_text:
                await query.message.edit_text(new_text, reply_markup=query.message.reply_markup)
        except Exception as e:
            print(f"Ошибка при обновлении сообщения о раскрытии: {e}")
        return

    # Обновляем сообщение после движения
    new_text = game.display_board()
    try:
        if query.message.text is not None and query.message.text != new_text:
            await query.message.edit_text(new_text, reply_markup=query.message.reply_markup)
    except Exception as e:
        print(f"Ошибка при обновлении сообщения о движении: {e}")

async def reveal_cell(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обрабатывает команду /reveal. Открывает клетку по заданным координатам.
    """
    chat_id = update.message.chat.id
    if chat_id not in games:
        await update.message.reply_text('Сначала начни новую игру с помощью /newgame или /setgame.')
        return
    game = games[chat_id]
    try:
        x, y = map(int, context.args)
        if game.reveal(x, y):
            await update.message.reply_text(game.display_board())
            if (x, y) in game.mines_set:
                await update.message.reply_text('Вы попали на мину! Игра окончена.')
                del games[chat_id]
        else:
            await update.message.reply_text('Эта клетка уже открыта или содержит мину.')
    except (ValueError, IndexError):
        await update.message.reply_text('Пожалуйста, укажите корректные координаты в формате: /reveal x y.')
