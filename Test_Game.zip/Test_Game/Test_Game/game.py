﻿import random

class Minesweeper:
    def __init__(self, width, height, mines):
        """
        Инициализация игрового поля.
        
        :param width: Ширина поля.
        :param height: Высота поля.
        :param mines: Количество мин на поле.
        """
        self.width = width
        self.height = height
        self.mines = mines
        self.board = [[' ' for _ in range(self.width)] for _ in range(self.height)]
        self.mines_set = set()
        self.revealed = set()
        self.player_x = 0  # Начальная позиция игрока
        self.player_y = 0

    def place_mines(self):
        """
        Размещает мины на поле случайным образом.
        """
        while len(self.mines_set) < self.mines:
            x = random.randint(0, self.width - 1)
            y = random.randint(0, self.height - 1)
            if (x, y) not in self.mines_set:
                self.mines_set.add((x, y))
                self.board[y][x] = '*'

    def calculate_numbers(self):
        """
        Рассчитывает количество мин вокруг каждой клетки и обновляет игровое поле.
        """
        for x, y in self.mines_set:
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < self.width and 0 <= ny < self.height and self.board[ny][nx] != '*':
                        if self.board[ny][nx] == ' ':
                            self.board[ny][nx] = '1'
                        else:
                            self.board[ny][nx] = str(int(self.board[ny][nx]) + 1)

    def reveal(self, x, y):
        """
        Открывает клетку на поле.
        
        :param x: Координата по оси X.
        :param y: Координата по оси Y.
        :return: True, если клетка успешно открыта; False, если она уже открыта или содержит мину.
        """
        if (x, y) in self.revealed or (x, y) in self.mines_set:
            return False
        self.revealed.add((x, y))
        return True

    def display_board(self):
        """
        Форматирует и возвращает текущее состояние игрового поля для отображения.
        
        :return: Строка, представляющая текущее состояние поля.
        """
        display = ''
        for y in range(self.height):
            for x in range(self.width):
                if (x, y) == (self.player_x, self.player_y):
                    display += '🤖'  # Обозначим игрока
                elif (x, y) in self.revealed:
                    display += self.board[y][x]
                else:
                    display += '⬜️'  # Закрытая клетка
            display += '\n'
        return display
